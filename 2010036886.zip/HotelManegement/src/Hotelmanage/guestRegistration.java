package Hotelmanage;

import java.awt.Choice;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class guestRegistration implements ActionListener {
	
	//ȸ������ �г�
	private JFrame guestregiFrame;
	private JLabel guestNameLabel, guestSexLabel, guestAddressLabel, guestPhoneNumberLabel;
	private JButton guestRegiButton, guestCancelButton;
	private JTextField insertGuestName, insertGuestPhoneNumber;
	private Choice guest_sexChoice, guest_AddressChoice;
  
	public void guestRegistration(){
		guestregiFrame = new JFrame("ȸ������");
		guestregiFrame.setLayout(null); 			
		
		guestNameLabel = new JLabel("�� �� ��"); 
		guestNameLabel.setBounds(40,40,60,30);			
		
		guestSexLabel = new JLabel("����");
		guestSexLabel.setBounds(40,80,60,30);
					
		guestAddressLabel = new JLabel("�ּ�");
		guestAddressLabel.setBounds(40,120,60,30);
				
		guestPhoneNumberLabel = new JLabel("����ó");
		guestPhoneNumberLabel.setBounds(40,160,60,30);
					
		guestRegiButton = new JButton("ȸ������");
		guestRegiButton.setBounds(40,230,100,30);
		
		guestRegiButton.addActionListener(this);
		
		guestCancelButton = new JButton("���");
		guestCancelButton.setBounds(200,230,60,30);
		
		guestCancelButton.addActionListener(this);
		
		insertGuestName = new JTextField(10);
		insertGuestName.setBounds(160,40,100,30);
		
		insertGuestPhoneNumber = new JTextField(10);
		insertGuestPhoneNumber.setBounds(160, 160, 100, 30);			
		
		guest_sexChoice = new Choice();
		guest_sexChoice.add("��");   guest_sexChoice.add("��");
		guest_sexChoice.setBounds(160,80,100,30);			
		
		guest_AddressChoice = new Choice();		
		guest_AddressChoice.add("����");     guest_AddressChoice.add("��������");
		guest_AddressChoice.add("�������");   guest_AddressChoice.add("��������");
		guest_AddressChoice.add("��û����");   guest_AddressChoice.add("�������");
		guest_AddressChoice.add("���ֵ�"); 
		guest_AddressChoice.setBounds(160,120,100,30);
					
		guestregiFrame.add(guestNameLabel); 			guestregiFrame.add(guestSexLabel);
		guestregiFrame.add(guestAddressLabel);			guestregiFrame.add(guestPhoneNumberLabel);
		guestregiFrame.add(guestRegiButton);			guestregiFrame.add(guestCancelButton);
		guestregiFrame.add(insertGuestName);				    guestregiFrame.add(insertGuestPhoneNumber);
		guestregiFrame.add(guest_sexChoice);			guestregiFrame.add(guest_AddressChoice);			
	
		guestregiFrame.setSize(350, 350); // ������ ũ��
		guestregiFrame.setLocation(650, 300); // ������ ��ġ
		guestregiFrame.setVisible(true);
		guestregiFrame.setDefaultCloseOperation(guestregiFrame.DISPOSE_ON_CLOSE);
		
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == guestRegiButton){	
			if(insertGuestName.getText().trim().length() == 0 || insertGuestPhoneNumber.getText().trim().length() == 0 ){
				JOptionPane.showMessageDialog(null, "�Է¶��� ����ֽ��ϴ�.");
			}else{
				try{
					login.db.regiPerson("guest", insertGuestName.getText().trim(), guest_sexChoice.getSelectedItem(), guest_AddressChoice.getSelectedItem(), Integer.parseInt(insertGuestPhoneNumber.getText().trim()));	 
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null, "�̸����̸� 10�ڳ���, ���ڴ� 5�ڸ��� �Է��ϼž� �մϴ�.");
				}	
			}								
		  // GuestRegistration() ��ҹ�ư �������� => ȸ�� ���� ����	    	
		}else if(e.getSource() == guestCancelButton){
			if(insertGuestName.getText().trim().length() == 0 || insertGuestPhoneNumber.getText().trim().length() == 0 ){
				JOptionPane.showMessageDialog(null, "�Է¶��� ����ֽ��ϴ�.");
			}
			else{
				try{
					login.db.deletePerson("guest", insertGuestName.getText().trim());					
				}catch(SQLException e1){
					JOptionPane.showMessageDialog(null, "Ż��������� ������ �߻��߽��ϴ� : " + e1);
				}
			}
			
		}
		
	}
}
